﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_5.Boolean_Variable
{
    class Program
    {
        static void Main(string[] args)
        {


            
           int male = 1;
           int female = 2;
           bool isFemale = (male < female);
           Console.WriteLine("My gender is male: {0}", isFemale);
            
        }
    }
}
