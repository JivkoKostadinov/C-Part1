﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_1.Declare_Variables
{
    class Program
    {
        static void Main(string[] args)
        {
            byte a = 97;
            sbyte b = -115;
            short c = -10000;
            int d = 52130;
            long e = 4825932;

            Console.WriteLine("{0}\n{1}\n{2}\n{3}\n{4}",a,b,c,d,e);


        }
    }
}
