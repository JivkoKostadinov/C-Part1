﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_13.Comparing_Floats
{
    class Program
    {
        static void Main(string[] args)
        {
            int characters = 126;
            for (int i = 0; i <= characters; i++)
            {

                Console.Write((char)i);
            }
            Console.WriteLine();
        }
    }
}
