﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_8.Isosceles_Triangle
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;
            char copyright = '\u00A9';
            Console.WriteLine(" " + " " + " " + copyright);
            Console.WriteLine(" " + " " + copyright + " " + copyright);
            Console.WriteLine(" " + copyright + " " + " " + " " + copyright);
            Console.WriteLine(copyright + " " + copyright + " " + copyright + " " + copyright);
        }
    }
}
